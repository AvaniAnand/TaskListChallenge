import React from 'react'

function Edit() {
  return (
    <React.Fragment>
      <h1>Edit</h1>
      <p>This is page is still being developed by Avani</p>
    </React.Fragment>
  )
}


export default Edit;
