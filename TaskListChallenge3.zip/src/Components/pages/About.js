import React from 'react'

function About() {
  return (
    <React.Fragment>
      <h1>About</h1>
      <p>This is the TodoList app v1.0.0. It is part of a React code challenge attempted by Avani Anand on 11/07/2021
      </p>
    </React.Fragment>
  )
}


export default About;